import app from "./app";
import { logger } from "./lib/logger";
import { startAiGenerateJobRunner } from "./routes/ai";
import { startWorkspaceRunner } from "./lib/workspace-runner";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

void startAiGenerateJobRunner().catch((err) => {
  logger.error({ err }, "Failed to recover queued AI generation jobs");
});

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  startWorkspaceRunner();
});
